package hr.fer.zemris.java.hw11.jnotepadpp.local;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public abstract class AbstractLocalizationProvider implements ILocalizationProvider {

	private List<ILocalizationListener> listeners;

	public AbstractLocalizationProvider() {
		listeners = new ArrayList<>();
	}

	@Override
	public void addLocalizationListener(ILocalizationListener listener) {
		Objects.requireNonNull(listener, "Listener to be added can't be null.");
		listeners.add(listener);
	}

	@Override
	public void removeLocalizationListener(ILocalizationListener listener) {
		Objects.requireNonNull(listener, "Listener to be removed can't be null.");
		listeners.remove(listener);
	}

	public void fire() {
		listeners.stream().forEach((listener) -> listener.localizationChanged());
	}
}
