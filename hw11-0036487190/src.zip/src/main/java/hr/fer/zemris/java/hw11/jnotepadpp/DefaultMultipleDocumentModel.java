package hr.fer.zemris.java.hw11.jnotepadpp;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DefaultMultipleDocumentModel extends JTabbedPane implements MultipleDocumentModel {

	private static final long serialVersionUID = 1L;

	private static ImageIcon RED_ICON;
	private static ImageIcon GREEN_ICON;

	private List<SingleDocumentModel> models;
	private SingleDocumentModel currentModel;

	private List<MultipleDocumentListener> listeners;

	public DefaultMultipleDocumentModel() {

		this.models = new ArrayList<>();
		this.listeners = new ArrayList<>();

		this.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				int index = getSelectedIndex();
				if (index == -1) {
					return;
				} else {
					SingleDocumentModel previousModel = currentModel;
					currentModel = getDocument(getSelectedIndex());
					notifyCurrentDocumentChanged(previousModel, currentModel);
				}
			}
		});

		try {
			readIcons();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	private void readIcons() throws IOException {
		InputStream is3 = this.getClass().getResourceAsStream("icons/redDisk.png");
		byte[] bytes = is3.readAllBytes();
		// is3.close();
		RED_ICON = new ImageIcon(bytes);

		is3 = this.getClass().getResourceAsStream("icons/blueDisk.png");
		bytes = is3.readAllBytes();
		is3.close();
		GREEN_ICON = new ImageIcon(bytes);

	}

	private void notifyCurrentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
		listeners.forEach(listener -> listener.currentDocumentChanged(previousModel, currentModel));
	}

	@Override
	public SingleDocumentModel createNewDocument() {
		SingleDocumentModel model = new DefaultSingleDocumentModel("", null);
		models.add(model);
		addTab("new document", new JPanel().add(new JScrollPane(model.getTextComponent())));
		this.setSelectedIndex(models.size() - 1);

		setIconAt(getSelectedIndex(), GREEN_ICON);
		addIconListener();
		return model;
	}

	private void addIconListener() {
		currentModel.addSingleDocumentListener(new SingleDocumentListener() {

			@Override
			public void documentModifyStatusUpdated(SingleDocumentModel model) {
				if (model.isModified()) {
					setIconAt(getSelectedIndex(), RED_ICON);
				} else {
					setIconAt(getSelectedIndex(), GREEN_ICON);
				}
			}

			@Override
			public void documentFilePathUpdated(SingleDocumentModel model) {
				setTitleAt(getSelectedIndex(), model.getFilePath().getFileName().toString());
				setToolTipTextAt(getSelectedIndex(), model.getFilePath().toString());
				notifyCurrentDocumentChanged(null, model);
			}
		});
	}

	@Override
	public SingleDocumentModel getCurrentDocument() {
		return currentModel;
	}

	@Override
	public SingleDocumentModel loadDocument(Path path) {
		Objects.requireNonNull(path, "Path can't be null");

		File fileName = path.toFile();

		if (!Files.isReadable(path)) {
			JOptionPane.showMessageDialog(DefaultMultipleDocumentModel.this,
					"File " + fileName.getAbsolutePath() + " doesn't exist.", "Error", JOptionPane.ERROR_MESSAGE);
			return null;
		}

		byte[] buff;
		try {
			buff = Files.readAllBytes(path);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(DefaultMultipleDocumentModel.this,
					"Error when trying to read file " + fileName.getAbsolutePath(), "Error", JOptionPane.ERROR_MESSAGE);
			return null;
		}
		String text = new String(buff, StandardCharsets.UTF_8);

		SingleDocumentModel model = new DefaultSingleDocumentModel(text, path);

		if (!models.contains(model)) {
			models.add(model);
			addTab(fileName.getName().toString(), null, new JPanel().add(new JScrollPane(model.getTextComponent())),
					fileName.toString());
			this.setSelectedIndex(models.size() - 1);

		} else {
			this.setSelectedIndex(models.indexOf(model));
		}
		setIconAt(getSelectedIndex(), GREEN_ICON);
		addIconListener();
		return model;
	}

	@Override
	public void saveDocument(SingleDocumentModel model, Path newPath) {

		byte[] data = model.getTextComponent().getText().getBytes(StandardCharsets.UTF_8);
		try {
			Files.write(newPath, data);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(DefaultMultipleDocumentModel.this,
					"Error while trying to save file." + newPath.toAbsolutePath(), "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		List<SingleDocumentModel> documentsCopy = new ArrayList<>(models);
		documentsCopy.remove(currentModel);

		for (SingleDocumentModel document : documentsCopy) {
			Path path = document.getFilePath();
			if (path != null) {

				if (newPath.equals(path)) {
					JOptionPane.showMessageDialog(DefaultMultipleDocumentModel.this,
							"Can't save file since demanded file with demanded file is being edited."
									+ newPath.toAbsolutePath(),
							"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
		}
		currentModel.setFilePath(newPath);
		JOptionPane.showMessageDialog(DefaultMultipleDocumentModel.this, "File was saved.", "Information",
				JOptionPane.INFORMATION_MESSAGE);
		currentModel.setModified(false);

	}

	@Override
	public void closeDocument(SingleDocumentModel model) {
		models.remove(getSelectedIndex());
		remove(getSelectedIndex());
		listeners.forEach(listener -> listener.documentRemoved(currentModel));
	}

	@Override
	public void addMultipleDocumentListener(MultipleDocumentListener l) {
		Objects.requireNonNull(l, "Listener can't be null");
		listeners.add(l);
	}

	@Override
	public void removeMultipleDocumentListener(MultipleDocumentListener l) {
		Objects.requireNonNull(l, "Listener can't be null");
		listeners.remove(l);
	}

	@Override
	public int getNumberOfDocuments() {
		return models.size();
	}

	@Override
	public SingleDocumentModel getDocument(int index) {
		if (index < 0 || index > models.size() - 1) {
			throw new IllegalArgumentException("Invalid index. Valid index range is: [0," + models.size());
		}
		return models.get(index);
	}

	@Override
	public Iterator<SingleDocumentModel> iterator() {
		return models.iterator();
	}

}
