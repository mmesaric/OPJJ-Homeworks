package hr.fer.zemris.java.hw11.jnotepadpp.local;

public class LocalizationProviderBridge extends AbstractLocalizationProvider{

	private boolean connected;
	private ILocalizationProvider parent;
	private ILocalizationListener listener;

	public LocalizationProviderBridge(ILocalizationProvider parent) {
		this.parent = parent;
		connected = false;
	}

	public void connect() {
		if (connected) return;
		listener = new ILocalizationListener() {
			
			@Override
			public void localizationChanged() {
				
				fire();
			}
		};
		parent.addLocalizationListener(listener);
		connected = true;
	}

	public void disconnect() {
		if (!connected) return;
		parent.removeLocalizationListener(listener);
		connected = false;
	}

	public String getString(String key) {
		return parent.getString(key);
	}

}
