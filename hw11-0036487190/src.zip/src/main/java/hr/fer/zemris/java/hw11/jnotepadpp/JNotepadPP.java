package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class JNotepadPP extends JFrame {

	private DefaultMultipleDocumentModel multipleDocumentModel;

	private static final long serialVersionUID = 1L;

	private String copiedText = "";
	private volatile static boolean continueWork = true;

	private JLabel length;
	private JLabel ln;
	private JLabel col;
	private JLabel sel;

	public JNotepadPP() {

		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setLocation(200, 50);
		setTitle("JNotepad++");
		setSize(700, 500);

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				checkModifiedDocuments();
			}

		});
		length = new JLabel("length:");
		ln = new JLabel("Ln:");
		col = new JLabel("Col:");
		sel = new JLabel("Sel:");

		initGUI();
	}

	protected void checkModifiedDocuments() {
		Iterator<SingleDocumentModel> documents = multipleDocumentModel.iterator();
		List<SingleDocumentModel> copyOfDocuments = new ArrayList<>();

		while (documents.hasNext()) {
			copyOfDocuments.add(documents.next());
		}

		for (int i = copyOfDocuments.size() - 1; i >= 0; i--) {
			SingleDocumentModel model = copyOfDocuments.get(i);
			if (model.isModified()) {

				int response = JOptionPane.showConfirmDialog(JNotepadPP.this,
						"Do you want to save changes made to file?");

				if (response == 0) {
					if (model.getFilePath() == null) {
						saveAsDocumentAction.actionPerformed(null);

					} else {
						saveDocumentAction.actionPerformed(null);
					}
				} else if (response == 1) {
					model.setModified(false);
					multipleDocumentModel.closeDocument(model);
				} else {
					return;
				}
			} else {
				multipleDocumentModel.closeDocument(model);
			}
		}
		continueWork = false;
		dispose();
	}

	private void initGUI() {

		JPanel panel = new JPanel(new BorderLayout());

		multipleDocumentModel = new DefaultMultipleDocumentModel();

		multipleDocumentModel.addMultipleDocumentListener(new MultipleDocumentListener() {

			@Override
			public void documentRemoved(SingleDocumentModel model) {
				if (multipleDocumentModel.getNumberOfDocuments() == 0) {
					setTitle("JNotepad++");
					return;
				}
			}

			@Override
			public void documentAdded(SingleDocumentModel model) {

			}

			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				if (multipleDocumentModel.getNumberOfDocuments() == 0) {
					setTitle("JNotepad++");
					return;
				}

				if (currentModel.getFilePath() == null) {
					setTitle("New file - JNotepad++");
				} else {
					setTitle(currentModel.getFilePath().toString() + " - JNotepad++");
				}
				// if (previousModel == null) {
				// caret = new CaretListener() {
				JTextArea editor = currentModel.getTextComponent();
				editor.setFocusable(true);

				currentModel.getTextComponent().addCaretListener(new CaretListener() {

					@Override
					public void caretUpdate(CaretEvent e) {

						JTextArea editor = currentModel.getTextComponent();

						int len = editor.getCaret().getDot() - editor.getCaret().getMark();
						cutAction.setEnabled(len != 0);
						copyAction.setEnabled(len != 0);
						// pasteAction.setEnabled(copiedText.length()!=0);
						toUpperCaseAction.setEnabled(len != 0);
						toLowerCaseAction.setEnabled(len != 0);
						invertCaseAction.setEnabled(len != 0);

						calculateStatusBarFields(currentModel, editor);

					}

					private void calculateStatusBarFields(SingleDocumentModel currentModel, JTextArea editor) {

						int ln = 1;
						int col = 1;

						int caretPosition = editor.getCaretPosition();
						int length = editor.getText().length();
						JNotepadPP.this.length.setText("Length:" + length);
						try {
							ln = editor.getLineOfOffset(caretPosition);
							JNotepadPP.this.ln.setText("Ln:" + (ln + 1));
							col = caretPosition - editor.getLineStartOffset(ln);
							JNotepadPP.this.col.setText("Col:" + col);
							int sel = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
							JNotepadPP.this.sel.setText("Sel:" + sel);
						} catch (BadLocationException e) {
							e.printStackTrace();
						}
						;
					}
				});

				CaretListener oldCaretListener = currentModel.getTextComponent().getCaretListeners()[0];
				oldCaretListener.caretUpdate(null);
			}
		});

		panel.add(multipleDocumentModel, BorderLayout.CENTER);

		createMenusBars(panel);
		createActions();
		createToolbar(panel);
		createStatusBar(panel);

		this.getContentPane().add(panel);
	}

	private Action newBlankDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			multipleDocumentModel.createNewDocument();
		}
	};

	private Action openExistingDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if (fc.showOpenDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			File fileName = fc.getSelectedFile();
			Path filePath = fileName.toPath();
			multipleDocumentModel.loadDocument(filePath);
		}
	};

	private Action saveDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			if (multipleDocumentModel.getCurrentDocument() == null
					|| multipleDocumentModel.getNumberOfDocuments() == 0) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No changes to save.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			Path openedFilePath = multipleDocumentModel.getCurrentDocument().getFilePath();

			if (openedFilePath == null) {
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("Save document");
				if (jfc.showSaveDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing was saved.", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				openedFilePath = jfc.getSelectedFile().toPath();
			} else {
				openedFilePath = multipleDocumentModel.getCurrentDocument().getFilePath();
			}

			multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
		}
	};

	private Action saveAsDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			if (multipleDocumentModel.getCurrentDocument() == null
					|| multipleDocumentModel.getNumberOfDocuments() == 0) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No changes to save.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JFileChooser jfc = new JFileChooser();
			jfc.setDialogTitle("Save document");
			if (jfc.showSaveDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing was saved.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			Path openedFilePath = jfc.getSelectedFile().toPath();

			if (openedFilePath.toFile().exists()) {
				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to overwrite this file?", "Warning",
						JOptionPane.YES_NO_OPTION);
				if (dialogResult == 0) {
					multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
					return;
				} else {
					return;
				}
			}

			multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
		}
	};

	private Action closeDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel currentDocument = multipleDocumentModel.getCurrentDocument();

			if (currentDocument == null || multipleDocumentModel.getSelectedIndex() == -1) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing to close.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			if (currentDocument.isModified()) {
				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to save changes?", "Warning",
						JOptionPane.YES_NO_OPTION);
				if (dialogResult == 0) {
					saveDocumentAction.actionPerformed(null);
					multipleDocumentModel.closeDocument(currentDocument);
				} else {
					multipleDocumentModel.closeDocument(currentDocument);
				}
				return;
			}

			multipleDocumentModel.closeDocument(currentDocument);
		}
	};

	private Action copyAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				copiedText = doc.getText(offset, len);
				// doc.remove(offset, len);

			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}

		}
	};

	private Action cutAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				copiedText = doc.getText(offset, len);
				doc.remove(offset, len);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		}
	};

	private Action pasteAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				doc.remove(offset, len);
				doc.insertString(offset, copiedText, null);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}

		}
	};

	private  Action statisticsAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null || multipleDocumentModel.getNumberOfDocuments() == 0) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Open a document to show statistics", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			String text = currentModel.getTextComponent().getText();

			int numberOfCharacters = text.length();
			int numberOfNonBlankCharacters = text.replaceAll("\\s+", "").length();
			int numberOfLines = (int) (text.chars().filter(currentChar -> currentChar == '\n').count() + 1);

			JOptionPane.showMessageDialog(JNotepadPP.this,
					"Your document has " + numberOfCharacters + " characters, " + numberOfNonBlankCharacters
							+ " non-blank characters and " + numberOfLines + " lines.",
					"Information", JOptionPane.WARNING_MESSAGE);
		}
	};

	private final Action toUpperCaseAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			JTextArea editor = multipleDocumentModel.getCurrentDocument().getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				String toTransform = doc.getText(offset, len);
				doc.remove(offset, len);
				doc.insertString(offset, toTransform.toUpperCase(), null);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		}
	};

	private Action toLowerCaseAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			JTextArea editor = multipleDocumentModel.getCurrentDocument().getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				String toTransform = doc.getText(offset, len);
				doc.remove(offset, len);
				doc.insertString(offset, toTransform.toLowerCase(), null);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		}
	};

	private Action invertCaseAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			JTextArea editor = multipleDocumentModel.getCurrentDocument().getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			int offset = 0;

			if (len != 0) {
				offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());
			} else {
				len = doc.getLength();
			}

			try {
				String text = doc.getText(offset, len);
				text = changeCase(text);
				doc.remove(offset, len);
				doc.insertString(offset, text, null);
			} catch (BadLocationException ex) {
				ex.printStackTrace();
			}
		}

		private String changeCase(String text) {
			char[] znakovi = text.toCharArray();
			for (int i = 0; i < znakovi.length; i++) {
				char c = znakovi[i];
				if (Character.isLowerCase(c)) {
					znakovi[i] = Character.toUpperCase(c);
				} else if (Character.isUpperCase(c)) {
					znakovi[i] = Character.toLowerCase(c);
				}
			}
			return new String(znakovi);
		}
	};

	private final Action exitAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			checkModifiedDocuments();
		}
	};
	
	private final Action uniqueAction = new AbstractAction() {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			
			JTextArea editor = multipleDocumentModel.getCurrentDocument().getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			int offset = 0;

			if (len != 0) {
				offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());
			} else {
				len = doc.getLength();
			}

			try {
				String text = doc.getText(offset, len);
				doc.remove(offset, len);
				doc.insertString(offset, text, null);
			} catch (BadLocationException ex) {
				ex.printStackTrace();
			}
		}
	};

	private void createStatusBar(JPanel panel) {

		JPanel statusPanel = new JPanel();
		statusPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));
		panel.add(statusPanel, BorderLayout.SOUTH);
		statusPanel.setPreferredSize(new Dimension(getWidth(), 22));
		// statusPanel.setLayout(new BorderLayout(1, 0));
		statusPanel.setLayout(new GridLayout(1, 5));

		statusPanel.add(length);
		statusPanel.add(ln);
		statusPanel.add(col);
		statusPanel.add(sel);
		statusPanel.add(new ClockPane());

		panel.add(statusPanel, BorderLayout.SOUTH);
	}

	private void createToolbar(JPanel panel) {

		JToolBar toolBar = new JToolBar("Tools");
		toolBar.setFloatable(true);

		toolBar.add(new JButton(newBlankDocumentAction));
		toolBar.add(new JButton(openExistingDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(saveDocumentAction));
		toolBar.add(new JButton(saveAsDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(statisticsAction));

		toolBar.addSeparator();
		toolBar.add(new JButton(cutAction));
		toolBar.add(new JButton(copyAction));
		toolBar.add(new JButton(pasteAction));

		toolBar.addSeparator();
		toolBar.add(new JButton(exitAction));

		panel.add(toolBar, BorderLayout.PAGE_START);
	}

	private void createMenusBars(JPanel panel) {

		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");

		fileMenu.add(new JMenuItem(newBlankDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(openExistingDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(saveDocumentAction));
		fileMenu.add(new JMenuItem(saveAsDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(closeDocumentAction));
		fileMenu.add(new JMenuItem(exitAction));

		menuBar.add(fileMenu);

		JMenu infoMenu = new JMenu("Info");

		infoMenu.add(new JMenuItem(statisticsAction));

		menuBar.add(infoMenu);

		JMenu editMenu = new JMenu("Edit");

		editMenu.add(new JMenuItem(copyAction));
		editMenu.add(new JMenuItem(pasteAction));
		editMenu.add(new JMenuItem(cutAction));

		menuBar.add(editMenu);

		JMenu toolsMenu = new JMenu("Tools");
		
		JMenu changeCaseMenu = new JMenu("Change case");

		changeCaseMenu.add(new JMenuItem(toUpperCaseAction));
		changeCaseMenu.add(new JMenuItem(toLowerCaseAction));
		changeCaseMenu.add(new JMenuItem(invertCaseAction));
		
		toolsMenu.add(changeCaseMenu);

		menuBar.add(toolsMenu);

		this.getContentPane().add(menuBar, BorderLayout.NORTH);
	}

	private void createActions() {

		newBlankDocumentAction.putValue(Action.NAME, "New document");
		newBlankDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
		newBlankDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);
		newBlankDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Creates a blank document.");

		openExistingDocumentAction.putValue(Action.NAME, "Open");
		openExistingDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
		openExistingDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);
		openExistingDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Opens an existing document.");

		saveDocumentAction.putValue(Action.NAME, "Save");
		saveDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
		saveDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);
		saveDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Saves changes made to document.");

		saveAsDocumentAction.putValue(Action.NAME, "Save as");
		saveAsDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control A"));
		saveAsDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_A);
		saveAsDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Saves changes made to document as a new file.");

		closeDocumentAction.putValue(Action.NAME, "Close document");
		closeDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control X"));
		closeDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		closeDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Closes the document.");

		statisticsAction.putValue(Action.NAME, "Statistics");
		statisticsAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control T"));
		statisticsAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_T);
		statisticsAction.putValue(Action.SHORT_DESCRIPTION, "Shows document statistics.");

		cutAction.putValue(Action.NAME, "Cut");
		cutAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control U"));
		cutAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_U);
		cutAction.putValue(Action.SHORT_DESCRIPTION, "Cuts selected text.");
		cutAction.setEnabled(false);

		copyAction.putValue(Action.NAME, "Copy");
		copyAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control C"));
		copyAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		copyAction.putValue(Action.SHORT_DESCRIPTION, "Copies selected text.");
		copyAction.setEnabled(false);

		pasteAction.putValue(Action.NAME, "Paste");
		pasteAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control V"));
		pasteAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_P);
		pasteAction.putValue(Action.SHORT_DESCRIPTION, "Paste selected text.");

		exitAction.putValue(Action.NAME, "Exit");
		exitAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E"));
		exitAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
		exitAction.putValue(Action.SHORT_DESCRIPTION, "Exit the JNotepad++.");

		toUpperCaseAction.putValue(Action.NAME, "To upper case");
		toUpperCaseAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control P"));
		toUpperCaseAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_P);
		toUpperCaseAction.putValue(Action.SHORT_DESCRIPTION, "Changes the selected text to upper case");
		toUpperCaseAction.setEnabled(false);

		toLowerCaseAction.putValue(Action.NAME, "To lower case");
		toLowerCaseAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control W"));
		toLowerCaseAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_W);
		toLowerCaseAction.putValue(Action.SHORT_DESCRIPTION, "Changes the selected text to lower case.");
		toLowerCaseAction.setEnabled(false);

		invertCaseAction.putValue(Action.NAME, "Invert case");
		invertCaseAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control I"));
		invertCaseAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_I);
		invertCaseAction.putValue(Action.SHORT_DESCRIPTION, "Inverts the case of selected text.");
		invertCaseAction.setEnabled(false);

	}

	static class ClockPane extends JPanel {

		private static final long serialVersionUID = 1L;
		private JLabel clock;

		public ClockPane() {
			setLayout(new BorderLayout());
			clock = new JLabel();
			clock.setHorizontalAlignment(JLabel.RIGHT);
			clock.setFont(new Font("Arial", Font.BOLD, 11));
			setLabelDate();
			add(clock);

			final int HALF_A_SECOND = 500;

			Timer timer = new Timer(HALF_A_SECOND, (ActionListener) new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (continueWork) {
						setLabelDate();
					} else {
						((Timer) e.getSource()).stop();
					}
				}
			});
			timer.setRepeats(true);
			timer.start();
		}

		public void setLabelDate() {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			clock.setText(formatter.format(new Date()));
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			new JNotepadPP().setVisible(true);
		});
	}

}
