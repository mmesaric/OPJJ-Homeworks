package hr.fer.zemris.java.hw11.jnotepadpp;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class DefaultSingleDocumentModel implements SingleDocumentModel {

	private JTextArea textArea;
	private Path path;
	private boolean modified;

	private List<SingleDocumentListener> listeners;

	public DefaultSingleDocumentModel(String text, Path path) {
		super();

		this.textArea = new JTextArea();
		textArea.setText(text);
		this.path = path;
		this.listeners = new ArrayList<>();

		textArea.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void removeUpdate(DocumentEvent e) {
				if (!isModified()) {
					setModified(true);
				}
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				if (!isModified()) {
					setModified(true);
				}
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				if(!isModified()) {
					setModified(true);
				}
			}
		});
	}

	@Override
	public JTextArea getTextComponent() {
		return textArea;
	}

	@Override
	public Path getFilePath() {
		return path;
	}

	@Override
	public void setFilePath(Path path) {
		Objects.requireNonNull(path, "Path can't be null.");
		this.path = path;
		listeners.forEach((listener) -> listener.documentFilePathUpdated(this));
	}

	@Override
	public boolean isModified() {
		return modified;
	}

	@Override
	public void setModified(boolean modified) {
		this.modified = modified;
		notifyObservers();
	}

	private void notifyObservers() {
		listeners.forEach((listener) -> listener.documentModifyStatusUpdated(this));
	}

	@Override
	public void addSingleDocumentListener(SingleDocumentListener l) {
		Objects.requireNonNull(l, "Listener can't be null.");
		listeners.add(l);
	}

	@Override
	public void removeSingleDocumentListener(SingleDocumentListener l) {
		Objects.requireNonNull(l, "Listener can't be null.");
		listeners.remove(l);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((path == null) ? 0 : path.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultSingleDocumentModel other = (DefaultSingleDocumentModel) obj;
		if (path == null) {
			if (other.path != null)
				return false;
		} else if (!path.equals(other.path))
			return false;
		return true;
	}
}
