package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class JNotepadPP extends JFrame {

	// private JTabbedPane tabbedPane;

	private DefaultMultipleDocumentModel multipleDocumentModel;

	private static final long serialVersionUID = 1L;

	private String copiedText = "";

	public JNotepadPP() {
		// tabbedPane = new JTabbedPane();

		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setLocation(200, 50);
		setTitle("JNotepad++");
		setSize(700, 500);

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				checkModifiedDocuments();
			}

		});

		initGUI();
	}

	protected void checkModifiedDocuments() {
		Iterator<SingleDocumentModel> documents = multipleDocumentModel.iterator();
		List<SingleDocumentModel> copyOfDocuments = new ArrayList<>();

		while (documents.hasNext()) {
			copyOfDocuments.add(documents.next());
		}

		for (int i = copyOfDocuments.size() - 1; i >= 0; i--) {
			SingleDocumentModel model = copyOfDocuments.get(i);
			if (model.isModified()) {

				int response = JOptionPane.showConfirmDialog(JNotepadPP.this,
						"Do you want to save changes made to file?");

				if (response == 0) {
					if (model.getFilePath() == null) {
						saveAsDocumentAction.actionPerformed(null);

					} else {
						saveDocumentAction.actionPerformed(null);
					}
				} else if (response == 1) {
					model.setModified(false);
					multipleDocumentModel.closeDocument(model);
				} else {
					return;
				}
			} else {
				multipleDocumentModel.closeDocument(model);
			}
		}
		dispose();
	}

	private void initGUI() {

		JPanel panel = new JPanel(new BorderLayout());

		multipleDocumentModel = new DefaultMultipleDocumentModel();

		multipleDocumentModel.addMultipleDocumentListener(new MultipleDocumentListener() {

			@Override
			public void documentRemoved(SingleDocumentModel model) {
				if (multipleDocumentModel.getNumberOfDocuments() == 0) {
					setTitle("JNotepad++");
					return;
				}
			}

			@Override
			public void documentAdded(SingleDocumentModel model) {

			}

			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				if (multipleDocumentModel.getNumberOfDocuments() == 0) {
					setTitle("JNotepad++");
					return;
				}

				if (currentModel.getFilePath() == null) {
					setTitle("New file - JNotepad++");
				} else {
					setTitle(currentModel.getFilePath().toString() + " - JNotepad++");
				}
			}
		});

		panel.add(multipleDocumentModel, BorderLayout.CENTER);

		createMenusBars(panel);
		createActions();
		createToolbar(panel);
		createStatusBar(panel);

		// panel.add(tabbedPane, BorderLayout.CENTER);

		this.getContentPane().add(panel);
	}

	private final Action newBlankDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			multipleDocumentModel.createNewDocument();
		}
	};

	private final Action openExistingDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if (fc.showOpenDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			File fileName = fc.getSelectedFile();
			Path filePath = fileName.toPath();
			multipleDocumentModel.loadDocument(filePath);
		}
	};

	private final Action saveDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			if (multipleDocumentModel.getCurrentDocument() == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No changes to save.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			Path openedFilePath = multipleDocumentModel.getCurrentDocument().getFilePath();

			if (openedFilePath == null) {
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("Save document");
				if (jfc.showSaveDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing was saved.", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				openedFilePath = jfc.getSelectedFile().toPath();
			} else {
				openedFilePath = multipleDocumentModel.getCurrentDocument().getFilePath();
			}

			multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
		}
	};

	private final Action saveAsDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			if (multipleDocumentModel.getCurrentDocument() == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No changes to save.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JFileChooser jfc = new JFileChooser();
			jfc.setDialogTitle("Save document");
			if (jfc.showSaveDialog(JNotepadPP.this) != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing was saved.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			Path openedFilePath = jfc.getSelectedFile().toPath();

			if (openedFilePath.toFile().exists()) {
				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to overwrite this file?", "Warning",
						JOptionPane.YES_NO_OPTION);
				if (dialogResult == 0) {
					multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
					return;
				} else {
					return;
				}
			}

			multipleDocumentModel.saveDocument(multipleDocumentModel.getCurrentDocument(), openedFilePath);
		}
	};

	private final Action closeDocumentAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			SingleDocumentModel currentDocument = multipleDocumentModel.getCurrentDocument();

			if (currentDocument == null || multipleDocumentModel.getSelectedIndex() == -1) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing to close.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			if (currentDocument.isModified()) {
				int dialogResult = JOptionPane.showConfirmDialog(null, "Do you want to save changes?", "Warning",
						JOptionPane.YES_NO_OPTION);
				if (dialogResult == 0) {
					saveDocumentAction.actionPerformed(null);
					multipleDocumentModel.closeDocument(currentDocument);
				} else {
					multipleDocumentModel.closeDocument(currentDocument);
				}
				return;
			}

			multipleDocumentModel.closeDocument(currentDocument);
		}
	};

	private final Action copyAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				copiedText = doc.getText(offset, len);
				// doc.remove(offset, len);

			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}

		}
	};

	private final Action cutAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			if (len == 0)
				return;
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				copiedText = doc.getText(offset, len);
				doc.remove(offset, len);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		}
	};

	private final Action pasteAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "No document is open.", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			JTextArea editor = currentModel.getTextComponent();
			Document doc = editor.getDocument();
			int len = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			int offset = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				doc.remove(offset, len);
				doc.insertString(offset, copiedText, null);
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}

		}
	};

	private final Action statisticsAction = new AbstractAction() {

		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {

			SingleDocumentModel currentModel = multipleDocumentModel.getCurrentDocument();
			if (currentModel == null) {
				JOptionPane.showMessageDialog(JNotepadPP.this, "Open a document to show statistics", "Warning",
						JOptionPane.WARNING_MESSAGE);
				return;
			}
			String text = currentModel.getTextComponent().getText();

			int numberOfCharacters = text.length();
			int numberOfNonBlankCharacters = text.replaceAll("\\s+", "").length();
			int numberOfLines = (int) (text.chars().filter(currentChar -> currentChar == '\n').count() + 1);

			JOptionPane.showMessageDialog(JNotepadPP.this,
					"Your document has " + numberOfCharacters + " characters, " + numberOfNonBlankCharacters
							+ " non-blank characters and " + numberOfLines + " lines.",
					"Information", JOptionPane.WARNING_MESSAGE);
		}
	};
	
	private final Action exitAction = new AbstractAction() {
		
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			checkModifiedDocuments();
		}
	};
	
	private void createStatusBar(JPanel panel) {
		
		JPanel statusPanel = new JPanel();
		statusPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));
		panel.add(statusPanel, BorderLayout.SOUTH);
		statusPanel.setPreferredSize(new Dimension(getWidth(), 23));
//		statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
		JLabel statusLabel = new JLabel("status");
		statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
		statusLabel.setVerticalAlignment(SwingConstants.CENTER);

		statusPanel.add(statusLabel);
	}

	private void createToolbar(JPanel panel) {

		JToolBar toolBar = new JToolBar("Tools");
		toolBar.setFloatable(true);

		toolBar.add(new JButton(newBlankDocumentAction));
		toolBar.add(new JButton(openExistingDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(saveDocumentAction));
		toolBar.add(new JButton(saveAsDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeDocumentAction));
		toolBar.addSeparator();
		toolBar.add(new JButton(statisticsAction));

		toolBar.addSeparator();
		toolBar.add(new JButton(cutAction));
		toolBar.add(new JButton(copyAction));
		toolBar.add(new JButton(pasteAction));

		toolBar.addSeparator();
		toolBar.add(new JButton(exitAction));

		panel.add(toolBar, BorderLayout.PAGE_START);
	}

	private void createMenusBars(JPanel panel) {

		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");

		fileMenu.add(new JMenuItem(newBlankDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(openExistingDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(saveDocumentAction));
		fileMenu.add(new JMenuItem(saveAsDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(closeDocumentAction));
		fileMenu.add(new JMenuItem(exitAction));


		menuBar.add(fileMenu);

		JMenu infoMenu = new JMenu("Info");

		infoMenu.add(new JMenuItem(statisticsAction));

		menuBar.add(infoMenu);

		JMenu editMenu = new JMenu("Edit");

		editMenu.add(new JMenuItem(copyAction));
		editMenu.add(new JMenuItem(pasteAction));
		editMenu.add(new JMenuItem(cutAction));

		menuBar.add(editMenu);

		// panel.add(menuBar, BorderLayout.NORTH);
		this.getContentPane().add(menuBar, BorderLayout.NORTH);
	}

	private void createActions() {

		newBlankDocumentAction.putValue(Action.NAME, "New document");
		newBlankDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
		newBlankDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);
		newBlankDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Creates a blank document.");

		openExistingDocumentAction.putValue(Action.NAME, "Open");
		openExistingDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
		openExistingDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);
		openExistingDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Opens an existing document.");

		saveDocumentAction.putValue(Action.NAME, "Save");
		saveDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
		saveDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);
		saveDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Saves changes made to document.");

		saveAsDocumentAction.putValue(Action.NAME, "Save as");
		saveAsDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control A"));
		saveAsDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_A);
		saveAsDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Saves changes made to document as a new file.");

		closeDocumentAction.putValue(Action.NAME, "Close document");
		closeDocumentAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control X"));
		closeDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		closeDocumentAction.putValue(Action.SHORT_DESCRIPTION, "Closes the document.");

		statisticsAction.putValue(Action.NAME, "Statistics");
		statisticsAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control T"));
		statisticsAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_T);
		statisticsAction.putValue(Action.SHORT_DESCRIPTION, "Shows document statistics.");

		cutAction.putValue(Action.NAME, "Cut");
		cutAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control U"));
		cutAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_U);
		cutAction.putValue(Action.SHORT_DESCRIPTION, "Cuts selected text.");

		copyAction.putValue(Action.NAME, "Copy");
		copyAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control C"));
		copyAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
		copyAction.putValue(Action.SHORT_DESCRIPTION, "Copies selected text.");

		pasteAction.putValue(Action.NAME, "Paste");
		pasteAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control V"));
		pasteAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_P);
		pasteAction.putValue(Action.SHORT_DESCRIPTION, "Paste selected text.");

		exitAction.putValue(Action.NAME, "Exit");
		exitAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E"));
		exitAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
		exitAction.putValue(Action.SHORT_DESCRIPTION, "Exit the JNotepad++.");

	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			new JNotepadPP().setVisible(true);
		});
	}

}
