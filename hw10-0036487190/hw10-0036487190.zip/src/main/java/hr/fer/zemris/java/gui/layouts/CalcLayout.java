package hr.fer.zemris.java.gui.layouts;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;

public class CalcLayout implements LayoutManager2 {

	private static final int MIN_ROW_COLUMN_NUMBER = 1;
	private static final int MAX_ROW_NUMBER = 5;
	private static final int MAX_COLUMN_NUMBER = 7;
	private static final RCPosition FIRST_COMPONENT = new RCPosition(1, 1);

	private Map<Component, RCPosition> components;
	private int gap;

	public CalcLayout() {
		this(0);
	}

	public CalcLayout(int gap) {
		if (gap < 0) {
			throw new CalcLayoutException("Gap can't be less than zero.");
		}
		this.gap = gap;
		this.components = new HashMap<>();
	}

	/**
	 * Adds the given component with specified name to the layout. Constraints are
	 * required in this implementation of layout so this method does nothing.
	 * {@inheritDoc}
	 */
	@Override
	public void addLayoutComponent(String name, Component component) {

	}

	@Override
	public void removeLayoutComponent(Component component) {
		Objects.requireNonNull(component, "Component to be removed can't be null.");

		components.remove(component);
	}

	@Override
	public void addLayoutComponent(Component component, Object constraint) {
		Objects.requireNonNull(component, "Component can't be null.");
		Objects.requireNonNull(constraint, "Constraint can't be null.");

		RCPosition position;
		if (constraint.getClass() == RCPosition.class) {
			position = (RCPosition) constraint;
		} else if (constraint.getClass() == String.class) {
			position = parsePositionFromString(constraint);
		} else {
			throw new CalcLayoutException("Constraint has to be either RCPosition or String.");
		}

		if (position.getRow() > MAX_ROW_NUMBER || position.getRow() < MIN_ROW_COLUMN_NUMBER
				|| position.getColumn() > MAX_COLUMN_NUMBER || position.getColumn() < MIN_ROW_COLUMN_NUMBER) {
			throw new CalcLayoutException(
					"Invalid row/column specification. Minimum number of columns and rows is " + MIN_ROW_COLUMN_NUMBER
							+ "Maximum number of rows is " + MAX_ROW_NUMBER + " and columns: " + MAX_COLUMN_NUMBER);
		}

		if (position.getRow() == 1 && (position.getColumn() == 2 || position.getColumn() == 3
				|| position.getColumn() == 4 || position.getColumn() == 5)) {
			throw new CalcLayoutException("Constraints with positions (1,2) to (1,5) can't be used.");
		}

		if (components.containsValue(position)) {
			throw new CalcLayoutException("Can't add multiple components with the same constraint.");
		}

		components.put(component, position);
	}

	private RCPosition parsePositionFromString(Object constraint) {
		String constraintString = String.valueOf(constraint);

		String[] constraintSplit = constraintString.split(",");
		if (constraintSplit.length != 2) {
			throw new CalcLayoutException("Constraint String must be in 'row,column' format.");
		}
		int row;
		int column;
		try {
			row = Integer.parseInt(constraintSplit[0]);
			column = Integer.parseInt(constraintSplit[1]);
		} catch (NumberFormatException e) {
			throw new CalcLayoutException("Invalid row or column value for RCPosition.");
		}

		return new RCPosition(row, column);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getLayoutAlignmentX(Container container) {
		return 0.5f;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getLayoutAlignmentY(Container container) {
		return 0.5f;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void invalidateLayout(Container container) {
	}

	@Override
	public void layoutContainer(Container container) {
		synchronized (container.getTreeLock()) {

			Insets insets = container.getInsets();
			int maxWidth = container.getWidth() - (insets.left + insets.right);
			int maxHeight = container.getHeight() - (insets.top + insets.bottom);

			int widthScaled = (maxWidth - (MAX_COLUMN_NUMBER*gap)) / (MAX_COLUMN_NUMBER);
			int heightScaled = (maxHeight - (MAX_ROW_NUMBER * gap)) / (MAX_ROW_NUMBER);

			for (Map.Entry<Component, RCPosition> entry : components.entrySet()) {
				Component component = entry.getKey();
				RCPosition position = entry.getValue();

				if (position.equals(FIRST_COMPONENT)) {
					component.setBounds(((position.getColumn() - 1) * (widthScaled)) + position.getColumn() * gap,
							((position.getRow() - 1) * heightScaled) + position.getRow() * gap,
							widthScaled * 5 + gap * 4, heightScaled);
				} else {
					component.setBounds(((position.getColumn() - 1) * (widthScaled)) + position.getColumn() * gap,
							((position.getRow() - 1) * heightScaled) + position.getRow() * gap, widthScaled, heightScaled);
				}

			}

			// Dimension preferredDimension = getPreferredDimension(container);
			// Dimension preferredLayoutSize = preferredLayoutSize(container);
			//
			//// double widthScaling = (double) maxWidth / preferredLayoutSize.getWidth();
			//// double heightScaling = (double) maxHeight /
			// preferredLayoutSize.getHeight();
			//
			// int widthScaling = maxWidth / preferredLayoutSize.width;
			// int heightScaling = maxHeight / preferredLayoutSize.height;
			//
			// Dimension finalDimension = new Dimension();
			// finalDimension.setSize(preferredDimension.getWidth() * widthScaling,
			// preferredDimension.getHeight() * heightScaling);
			//
			// for (Map.Entry<Component, RCPosition> entry : components.entrySet()) {
			//
			// Component component = entry.getKey();
			// RCPosition position = entry.getValue();
			//
			//// if (position.equals(FIRST_COMPONENT)) {
			//// component.setBounds(0, 0, finalDimension.width * 5 + gap * 4,
			// finalDimension.height);
			//// } else {
			//// component.setBounds((position.getColumn() - 1) * (gap +
			// finalDimension.width),
			//// (position.getRow() - 1) * (gap + finalDimension.height),
			// finalDimension.width,
			//// finalDimension.height);
			//// }
			//
			// if (position.equals(FIRST_COMPONENT)) {
			// component.setBounds(0, 0, widthScaling * 5 + gap * 4, heightScaling);
			// } else {
			// component.setBounds((position.getColumn() - 1) * (gap + widthScaling),
			// (position.getRow() - 1) * (gap + heightScaling), widthScaling,
			// heightScaling);
			// }
			// }
		}
	}

	public Dimension getPreferredDimension(Container container) {

		OptionalInt maxHeightOptional = components.keySet().stream().mapToInt(key -> key.getPreferredSize().height)
				.max();

		Map<Component, RCPosition> copiedComponents = new HashMap<>(components);
		copiedComponents.values().remove(FIRST_COMPONENT);

		OptionalInt maxWidthOptional = copiedComponents.keySet().stream().mapToInt(key -> key.getPreferredSize().width)
				.max();

		Optional<Component> startingComponent = components.entrySet().stream()
				.filter(entry -> entry.getValue().equals(FIRST_COMPONENT)).map(Map.Entry::getKey).findFirst();

		int maxHeight = 0;
		int maxWidth = 0;
		if (maxHeightOptional.isPresent()) {
			maxHeight = maxHeightOptional.getAsInt();
		}
		if (maxWidthOptional.isPresent()) {

			// if (startingComponent.isPresent()) {
			// maxWidth = startingComponent.get().getPreferredSize().width;
			// } else {
			// maxWidth = maxWidthOptional.getAsInt();
			// }
			maxWidth = maxWidthOptional.getAsInt();

		}

		return new Dimension(maxWidth, maxHeight);

	}

	@Override
	public Dimension preferredLayoutSize(Container container) {

		OptionalInt maxHeightOptional = components.keySet().stream().mapToInt(key -> key.getPreferredSize().height)
				.max();

		Map<Component, RCPosition> copiedComponents = new HashMap<>(components);
		copiedComponents.values().remove(FIRST_COMPONENT);

		OptionalInt maxWidthOptional = copiedComponents.keySet().stream().mapToInt(key -> key.getPreferredSize().width)
				.max();

		Optional<Component> startingComponent = components.entrySet().stream()
				.filter(entry -> entry.getValue().equals(FIRST_COMPONENT)).map(Map.Entry::getKey).findFirst();

		int maxHeight = 0;
		int maxWidth = 0;
		if (maxHeightOptional.isPresent()) {
			maxHeight = maxHeightOptional.getAsInt() * MAX_ROW_NUMBER + gap * (MAX_ROW_NUMBER - 1);
		}
		if (maxWidthOptional.isPresent()) {
			if (startingComponent.isPresent()) {
				maxWidth = startingComponent.get().getPreferredSize().width + gap * (MAX_COLUMN_NUMBER - 1)
						+ 2 * maxWidthOptional.getAsInt();
			} else {
				maxWidth = maxWidthOptional.getAsInt() * MAX_COLUMN_NUMBER + gap * (MAX_COLUMN_NUMBER - 1);
			}
		}

		Insets insets = container.getInsets();

		return new Dimension(insets.left + maxWidth + insets.right, insets.top + maxHeight + insets.bottom);


	}

	@Override
	public Dimension minimumLayoutSize(Container container) {

		OptionalInt maxHeightOptional = components.keySet().stream().mapToInt(key -> key.getMinimumSize().height).max();

		Map<Component, RCPosition> copiedComponents = new HashMap<>(components);
		copiedComponents.values().remove(FIRST_COMPONENT);

		OptionalInt maxWidthOptional = copiedComponents.keySet().stream().mapToInt(key -> key.getMinimumSize().width)
				.max();

		Optional<Component> startingComponent = components.entrySet().stream()
				.filter(entry -> entry.getValue().equals(FIRST_COMPONENT)).map(Map.Entry::getKey).findFirst();

		int maxHeight = 0;
		int maxWidth = 0;
		if (maxHeightOptional.isPresent()) {
			maxHeight = maxHeightOptional.getAsInt() * MAX_ROW_NUMBER + gap * (MAX_ROW_NUMBER - 1);
		}
		if (maxWidthOptional.isPresent()) {
			if (startingComponent.isPresent()) {
				maxWidth = startingComponent.get().getMinimumSize().width + gap * (MAX_COLUMN_NUMBER - 1)
						+ 2 * maxWidthOptional.getAsInt();
			} else {
				maxWidth = maxWidthOptional.getAsInt() * MAX_COLUMN_NUMBER + gap * (MAX_COLUMN_NUMBER - 1);
			}
		}

		Insets insets = container.getInsets();

		return new Dimension(insets.left + maxWidth + insets.right, insets.top + maxHeight + insets.bottom);

	}

	@Override
	public Dimension maximumLayoutSize(Container container) {

		OptionalInt maxHeightOptional = components.keySet().stream().mapToInt(key -> key.getMaximumSize().height).max();

		Map<Component, RCPosition> copiedComponents = new HashMap<>(components);
		copiedComponents.values().remove(FIRST_COMPONENT);

		OptionalInt maxWidthOptional = copiedComponents.keySet().stream().mapToInt(key -> key.getMaximumSize().width)
				.max();

		Optional<Component> startingComponent = components.entrySet().stream()
				.filter(entry -> entry.getValue().equals(FIRST_COMPONENT)).map(Map.Entry::getKey).findFirst();

		int maxHeight = 0;
		int maxWidth = 0;
		if (maxHeightOptional.isPresent()) {
			maxHeight = maxHeightOptional.getAsInt() * MAX_ROW_NUMBER + gap * (MAX_ROW_NUMBER - 1);
		}
		if (maxWidthOptional.isPresent()) {
			if (startingComponent.isPresent()) {
				maxWidth = startingComponent.get().getMaximumSize().width + gap * (MAX_COLUMN_NUMBER - 1)
						+ 2 * maxWidthOptional.getAsInt();
			} else {
				maxWidth = maxWidthOptional.getAsInt() * MAX_COLUMN_NUMBER + gap * (MAX_COLUMN_NUMBER - 1);
			}
		}

		Insets insets = container.getInsets();

		return new Dimension(insets.left + maxWidth + insets.right, insets.top + maxHeight + insets.bottom);

	}
}
