package hr.fer.zemris.java.gui.calc;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.DoubleBinaryOperator;

public class CalcModelImpl implements CalcModel {

	private String currentValue;
	private String activeOperand;
	private DoubleBinaryOperator pendingOperation;

	private List<CalcValueListener> observers;

	public CalcModelImpl() {
		this.observers = new ArrayList<>();
	}

	@Override
	public void addCalcValueListener(CalcValueListener l) {
		observers.add(l);
	}

	@Override
	public void removeCalcValueListener(CalcValueListener l) {
		observers.remove(l);
	}

	@Override
	public double getValue() {
		if (currentValue == null) {
			return 0;
		}
		return Double.parseDouble(currentValue);
	}

	@Override
	public void setValue(double value) {
		if (Double.isFinite(value) && !Double.isNaN(value)) {
			currentValue = Double.toString(value);
		}
	}

	@Override
	public void clear() {
		currentValue = "";
	}

	@Override
	public void clearAll() {
		currentValue = "";
		activeOperand = "";
		pendingOperation = null;
	}

	@Override
	public void swapSign() {
		if (currentValue != null && !currentValue.isEmpty()) {
			if (!currentValue.contains(".")) {

				int a = (int) getValue();
				if (currentValue.startsWith("-")) {
					currentValue = currentValue.substring(1, currentValue.length());
					return;
				} else {
					currentValue = "-" + Integer.toString(a);
					return;
				}
			}
			double value = getValue();
			value = -1 * value;
			setValue(value);
		}
	}

	@Override
	public void insertDecimalPoint() {

		if (currentValue != null && !currentValue.contains(".")) {
			currentValue += ".";
		}

		else if (currentValue == null || currentValue.isEmpty()) {
			currentValue = "0.";
		}

	}

	@Override
	public void insertDigit(int digit) {

		if (currentValue == null) {
			currentValue = Integer.toString(digit);
			return;
		}

		if (!currentValue.startsWith("-")) {
			double test = getValue() * 10 + (double) digit;
			if (Double.isInfinite(test)) {
				return;
			}
		}

		if (currentValue.startsWith("-")) {
			double test = getValue() * 10 + (double) digit;
			if (Double.isInfinite(test)) {
				return;
			}
		}

		if (currentValue.equals("0") && digit == 0) {
			return;
		}

		if (currentValue.equals("0") && digit != 0) {
			currentValue = Integer.toString(digit);
			return;
		}

		if (currentValue.equals("0.")) {
			currentValue += Integer.toString(digit);
			return;
		}

		currentValue += digit;
	}

	@Override
	public boolean isActiveOperandSet() {
		if (activeOperand == null || activeOperand.isEmpty()) {
			return false;
		}
		return true;
	}

	@Override
	public double getActiveOperand() {
		if (activeOperand == null || activeOperand.isEmpty()) {
			throw new IllegalStateException("Active operand is not set.");
		}
		return Double.parseDouble(activeOperand);
	}

	@Override
	public void setActiveOperand(double activeOperand) {

		if (Double.isFinite(activeOperand) && !Double.isNaN(activeOperand)) {
			this.activeOperand = Double.toString(activeOperand);
		}
	}

	@Override
	public void clearActiveOperand() {
		activeOperand = "";
	}

	@Override
	public DoubleBinaryOperator getPendingBinaryOperation() {
		return pendingOperation;
	}

	@Override
	public void setPendingBinaryOperation(DoubleBinaryOperator op) {
		Objects.requireNonNull(op, "Double binary operator can't be null.");

		if (pendingOperation != null) {
			setActiveOperand(op.applyAsDouble(getValue(), getActiveOperand()));
			clear();
		}

		pendingOperation = op;
	}

	@Override
	public String toString() {
		if (currentValue == null) {
			return "0";
		}
		return currentValue;
	}

}
