package hr.fer.zemris.math;

public class ComplexPolynomial {

}
