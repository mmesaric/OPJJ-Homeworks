package hr.fer.zemris.math;

import static java.lang.Math.sqrt;
import java.util.Objects;
import static java.lang.Math.pow;

public class Vector3 {

	private final double x;
	private final double y;
	private final double z;

	public Vector3(double x, double y, double z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public double norm() {
		return sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
	}

	public Vector3 normalized() {
		double norm = norm();

		if (norm == 0) {
			return new Vector3(0, 0, 0);
		}
		return new Vector3(x / norm, y / norm, z / norm);
	}

	public Vector3 add(Vector3 other) {
		Objects.requireNonNull(other, "Other vector to be added can't be null");

		return new Vector3(x + other.x, y + other.y, z + other.z);
	}

	public Vector3 sub(Vector3 other) {
		Objects.requireNonNull(other, "Other vector to be subtracted can't be null");

		return new Vector3(x - other.x, y - other.y, z - other.z);

	}

	public double dot(Vector3 other) {
		Objects.requireNonNull(other, "Other vector can't be null when calculating dot product.");

		return x * other.x + y * other.y + z * other.z;
	}

	public Vector3 cross(Vector3 other) {
		Objects.requireNonNull(other, "Other vector can't be null when calculating cross product.");

		double crossX = y * other.z - z * other.y;
		double crossY = z * other.x - x * other.z;
		double crossZ = x * other.y - y * other.x;

		return new Vector3(crossX, crossY, crossZ);
	}

	public Vector3 scale(double s) {

		return new Vector3(x * s, y * s, z * s);
	}

	public double cosAngle(Vector3 other) {
		Objects.requireNonNull(other, "Other vector can't be null when calculating cos value of two vectors' angles.");

		double dot = dot(other);
		double divideWith = this.norm() * other.norm();

		if (divideWith == 0) {
			throw new IllegalArgumentException("Can't devide with zero when calculating cos value.");
		}

		return dot / divideWith;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getZ() {
		return z;
	}

	public double[] toArray() {

		return new double[] { x, y, z };
	}

	public String toString() {
		return "(" + String.format("%.6f", x) + ", " + String.format("%.6f", y) + ", " + String.format("%.6f", z) + ")";
	}
}
