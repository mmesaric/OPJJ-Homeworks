package hr.fer.zemris.math;

import static java.lang.Math.sqrt;
import java.util.Objects;
import static java.lang.Math.pow;
import static java.lang.Math.atan2;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.PI;

import java.util.ArrayList;
import java.util.List;

public class Complex {

	public static final Complex ZERO = new Complex(0, 0);
	public static final Complex ONE = new Complex(1, 0);
	public static final Complex ONE_NEG = new Complex(-1, 0);
	public static final Complex IM = new Complex(0, 1);
	public static final Complex IM_NEG = new Complex(0, -1);

	private final double re;
	private final double im;

	public Complex() {
		this.re = 0;
		this.im = 0;
	}

	public Complex(double re, double im) {
		super();
		this.re = re;
		this.im = im;
	}

	public double module() {
		return sqrt(pow(re, 2) + pow(im, 2));
	}

	public Complex multiply(Complex other) {
		Objects.requireNonNull(other, "Other vector to be multiplied with cannot be null.");

		double real = (this.re * other.re) - (this.im * other.im);
		double imaginary = (this.re * other.im) + (this.im * other.re);

		return new Complex(real, imaginary);
	}

	public Complex divide(Complex other) {
		Objects.requireNonNull(other, "Other vector to be divided with cannot be null.");

		if (other.re == 0 || other.im == 0) {
			throw new IllegalArgumentException("Can't devide with zero.");
		}

		return new Complex(re / other.re, im / other.im);
	}

	public Complex add(Complex other) {
		Objects.requireNonNull(other, "Other vector to be added with cannot be null.");

		return new Complex(re + other.re, im + other.im);
	}

	public Complex sub(Complex other) {
		Objects.requireNonNull(other, "Other vector to be subtracted with cannot be null.");

		return new Complex(re - other.re, im - other.im);
	}

	public Complex negate() {
		return new Complex(-re, -im);
	}

	public Complex power(int n) {
		if (n < 0) {
			throw new IllegalArgumentException("When calculating power, n cannot be less than 0.");
		}
		if (n == 0) {
			return new Complex(1, 0);
		}

		double powerMagnitude = pow(this.module(), n);
		double otherReal = powerMagnitude * cos(n * atan2(re, im));
		double otherImaginary = powerMagnitude * sin(n * atan2(re, im));

		return new Complex(otherReal, otherImaginary);
	}

	public List<Complex> root(int n) {
		if (n <= 0) {
			throw new IllegalArgumentException("n has to be greater than 0 when calculating root");
		}

		List<Complex> roots = new ArrayList<>();

		if (n == 1) {
			roots.add(new Complex(re, im));
			return roots;
		}

		double magnitude = module();
		double angle = atan2(re, im);

		for (int i = 0; i < n; i++) {
			double real = pow(magnitude, (double) 1 / n) * cos((angle + 2 * PI * i) / n);
			double imaginary = pow(magnitude, (double) 1 / n) * sin((angle + 2 * PI * i) / n);
			roots.add(new Complex(real, imaginary));
		}

		return roots;
	}

	public double getRe() {
		return re;
	}

	public double getIm() {
		return im;
	}

	@Override
	public String toString() {
		return "(" + String.format("%.6f", re) + ", " + String.format("%.6f", im) + ")";
	}
}
