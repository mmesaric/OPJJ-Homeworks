package hr.fer.zemris.math;

import java.util.Objects;

public class ComplexRootedPolynomial {

	private Complex[] roots;

	public ComplexRootedPolynomial(Complex... roots) {
		Objects.requireNonNull(roots, "Reference to roots can't be null.");

		if (roots.length == 0) {
			throw new IllegalArgumentException("You have to pass at least one root complex number.");
		}

		this.roots = new Complex[roots.length];

		for (int i = 0; i < roots.length; i++) {
			this.roots[i] = roots[i];
		}

	}

	// computes polynomial value at given point z
	public Complex apply(Complex other) {
		Objects.requireNonNull(other, "Can't apply Rooted Polynomial on null.");

//		Complex function = other;
//
//		for (int i = 0; i < roots.length; i++) {
//			Complex current = roots[i];
//
//			if (i == 0) {
//				function = other.sub(current);
//
//			} else {
//				function = function.multiply(other.sub(current));
//
//			}
//		}
		
		Complex function = other.sub(roots[0]);

		for (int i = 1; i < roots.length; i++) {
			Complex current = roots[i];

			function = function.multiply(other.sub(current));

		}
		return function;
	}

	// converts this representation to ComplexPolynomial type
	public ComplexPolynomial toComplexPolynom() {
		return null;
	}

	@Override
	public String toString() {
		return "";
	}

	// finds index of closest root for given complex number z that is within
	// treshold; if there is no such root, returns -1
	public int indexOfClosestRootFor(Complex z, double treshold) {
		return 0;
	}

}
