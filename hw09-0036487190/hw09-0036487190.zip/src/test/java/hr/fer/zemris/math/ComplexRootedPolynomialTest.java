package hr.fer.zemris.math;

import org.junit.Assert;
import org.junit.Test;


public class ComplexRootedPolynomialTest {
	
	@Test
	public void constructorTest() {
		
		Complex[] roots = new Complex[] {new Complex(-2,1), new Complex(-2,-1)};
		Complex z = new Complex(0,0);
		
		Complex polynomial = new ComplexRootedPolynomial(roots).apply(z);
		
		Assert.assertEquals(5, polynomial.getRe(), 10E-3);
		Assert.assertEquals(0, polynomial.getIm(), 10E-3);
	}
	
	@Test
	public void constructorTest2() {
		
		Complex[] roots = new Complex[] {new Complex(-2,1), new Complex(-2,-1)};
		Complex z = new Complex(0,1);
		
		Complex polynomial = new ComplexRootedPolynomial(roots).apply(z);
		
		Assert.assertEquals(4, polynomial.getRe(), 10E-3);
		Assert.assertEquals(4, polynomial.getIm(), 10E-3);
	}

}
