package hr.fer.zemris.java.webserver.workers;

import java.io.IOException;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

public class EchoParams implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) throws Exception {
		
		String html = "<html><table border=\"1\">\n";
	
		context.setMimeType("text/html");
		
		for (String name : context.getParameterNames()) {
			html+= "<tr><td>" + context.getParameter(name) + "</td></tr>\n";
		}
		html+= "</table></html>\n";
		try {
			context.write(html);	
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

}
