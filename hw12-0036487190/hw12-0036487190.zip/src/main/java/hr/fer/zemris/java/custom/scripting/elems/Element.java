package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Base class for all elements used for representation of expressions
 * 
 * @author Marko Mesarić
 *
 */
public class Element {

	public String asText() {
		return "";
	}

}
