package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

public class BgColorWorker implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) throws Exception {

		String value = context.getParameter("bgcolor");
		if (value == null) {
			context.getDispatcher().dispatchRequest("/index2.html");
			context.write("Failed switching color.");
		}

		boolean validHex = true;

		for (int i = 0; i < value.length(); i++) {
			char currentChar = value.charAt(i);
			validHex = ((currentChar >= '0' && currentChar <= '9') || (currentChar >= 'a' && currentChar <= 'f')
					|| (currentChar >= 'A' && currentChar <= 'F'));
		}

		if (!validHex) {
			context.getDispatcher().dispatchRequest("/index2.html");
			context.write("Failed switching color.");
		}
		
		context.setPersistentParameter("bgcolor", value);
		context.getDispatcher().dispatchRequest("/index2.html");
		context.write("Succesfully switched color.");
	}

}
