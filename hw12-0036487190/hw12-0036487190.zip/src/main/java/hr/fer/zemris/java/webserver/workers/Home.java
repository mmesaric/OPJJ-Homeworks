package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

public class Home implements IWebWorker{

	@Override
	public void processRequest(RequestContext context) throws Exception {
				
		String param = context.getPersistentParameter("bgcolor");
		
		context.setTemporaryParameter("background", param==null? "7F7F7F": param);
		
		context.getDispatcher().dispatchRequest("/private/home.smscr");
	}
}
