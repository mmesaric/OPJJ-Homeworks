package hr.fer.zemris.java.webserver;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import hr.fer.zemris.java.custom.scripting.exec.SmartScriptEngine;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.webserver.RequestContext.RCCookie;

public class SmartHttpServer {

	private String address;
	private String domainName;
	private int port;
	private int workerThreads;
	private int sessionTimeout;
	private Map<String, String> mimeTypes = new HashMap<String, String>();
	private ServerThread serverThread;
	private ExecutorService threadPool;
	private Path documentRoot;
	private Map<String, IWebWorker> workersMap;

	private Map<String, SessionMapEntry> sessions = new HashMap<String, SmartHttpServer.SessionMapEntry>();
	private Random sessionRandom = new Random();

	private static final int SID_LENGTH = 20;
	private static final String SID_STRING = "sid";
	
	private Timer timer = new Timer();

	public SmartHttpServer(String configFileName) {

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream("./config/server.properties"));
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Couldn't find given server properties file.");
		} catch (IOException e) {
			throw new RuntimeException("Error when reading server properties file.");
		}

		address = properties.getProperty("server.address");
		domainName = properties.getProperty("server.domainName");
		port = Integer.parseInt(properties.getProperty("server.port"));
		workerThreads = Integer.parseInt(properties.getProperty("server.workerThreads"));
		sessionTimeout = Integer.parseInt(properties.getProperty("session.timeout"));

		documentRoot = Paths.get(properties.getProperty("server.documentRoot"));

		mimeTypes = loadMimeTypes(properties.getProperty("server.mimeConfig"));
		workersMap = loadWorkers(properties.getProperty("server.workers"));

//		timer.schedule(new SessionsCleanup(), 3, 3);
		
//		ScheduledExecutorService executor =
//			    Executors.newSingleThreadScheduledExecutor();
		
		ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
			
			@Override
			public Thread newThread(Runnable r) {
                Thread t = Executors.defaultThreadFactory().newThread(r);
                t.setDaemon(true);
                return t;
			}
		});
		
		exec.scheduleAtFixedRate(new SessionsCleanup(), 5, 5, TimeUnit.MINUTES);
	}
	
	class SessionsCleanup implements Runnable {

		@Override
		public void run() {		
			synchronized(sessions){
				Iterator<Map.Entry<String,SmartHttpServer.SessionMapEntry>> iter = sessions.entrySet().iterator();
				while(iter.hasNext()) {
					Map.Entry<String,SmartHttpServer.SessionMapEntry> entry = iter.next();
					if (entry.getValue().validUntil < (System.currentTimeMillis()/1000)) {
						iter.remove();
					}
				}
			}
		}
		
	}

	private Map<String, IWebWorker> loadWorkers(String workersFileName) {

		Map<String, IWebWorker> map = new HashMap<>();

		try {
			List<String> lines = Files.readAllLines(Paths.get(workersFileName));

			for (String line : lines) {
				if (line != null && !line.startsWith("#") && !line.isEmpty()) {
					String[] split = line.split("=");
					if (split.length != 2)
						throw new RuntimeException("Invalid workers properties.");

					String path = split[0].trim();
					String fqcn = split[1].trim();

					if (map.containsKey(path))
						throw new RuntimeException("Worker properties file can't contain duplicate paths.");

					Class<?> referenceToClass = Class.forName(fqcn);
					@SuppressWarnings("deprecation")
					Object newObject = referenceToClass.newInstance();
					IWebWorker iww = (IWebWorker) newObject;
					map.put(path, iww);
				}
			}

		} catch (IOException e) {
			throw new RuntimeException("Error when reading workers properties file.");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			throw new RuntimeException("Error when trying to find the class given in workers properties.");
		}

		return map;
	}

	private Map<String, String> loadMimeTypes(String mimeTypesFileName) {

		Map<String, String> map = new HashMap<>();

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(mimeTypesFileName));
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Couldn't find given mime types properties file.");
		} catch (IOException e) {
			throw new RuntimeException("Error when reading mime types properties file.");
		}

		for (Object key : properties.keySet()) {
			map.put(String.valueOf(key), String.valueOf(properties.get(key)));
		}

		return map;
	}

	protected synchronized void start() {
		if (serverThread == null) {
			serverThread = new ServerThread();
			serverThread.setDaemon(true);
			threadPool = Executors.newFixedThreadPool(workerThreads);
			serverThread.run();
		} else if (!serverThread.isAlive()) {
			serverThread = new ServerThread();
			serverThread.setDaemon(true);
			threadPool = Executors.newFixedThreadPool(workerThreads);
		}
	}

	protected synchronized void stop() {
		if (serverThread != null) {
			serverThread.interrupt();
			threadPool.shutdown();
		}
	}

	protected class ServerThread extends Thread {
		@Override
		public void run() {

			try (ServerSocket socket = new ServerSocket()) {
				socket.bind(new InetSocketAddress(address, port));
				socket.setSoTimeout(sessionTimeout * 1000);
				while (true) {
					Socket client = socket.accept();
					ClientWorker clientWorker = new ClientWorker(client);
					threadPool.submit(clientWorker);
				}
			} catch (IOException e) {
				// throw new RuntimeException("Error when creating socket.");
				e.printStackTrace();
			}
		}
	}

	private static class SessionMapEntry {
		String sid;
		String host;
		long validUntil;
		Map<String, String> map;

		public SessionMapEntry(String sid, String host, long validUntil, Map<String, String> map) {
			super();
			this.sid = sid;
			this.host = host;
			this.validUntil = validUntil;
			this.map = map;
		}
	}

	private class ClientWorker implements Runnable, IDispatcher {
		private Socket csocket;
		private PushbackInputStream istream;
		private OutputStream ostream;
		private String version;
		private String method;
		private String host;
		private Map<String, String> params = new HashMap<String, String>();
		private Map<String, String> tempParams = new HashMap<String, String>();
		private Map<String, String> permParams = new HashMap<String, String>();
		private List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();
		private String SID;
		private RequestContext context;

		public ClientWorker(Socket csocket) {
			super();
			this.csocket = csocket;
		}

		@Override
		public void run() {
			try {

				istream = new PushbackInputStream(csocket.getInputStream());
				ostream = csocket.getOutputStream();
				List<String> request = readRequest();
				if (request == null || request.size() < 1) {
					return;
				}
				String[] firstLine = request.get(0).split(" ");
				if (firstLine == null || firstLine.length != 3) {
					sendError(400, "Bad request");
					return;
				}

				method = firstLine[0].toUpperCase();
				if (!method.equals("GET")) {
					sendError(405, "Method Not Allowed");
					return;
				}

				version = firstLine[2].toUpperCase();
				if (!version.equals("HTTP/1.1")) {
					sendError(505, "HTTP Version Not Supported");
					return;
				}

				host = domainName;
				for (String line : request) {
					if (line.startsWith("Host:")) {
						host = line.split(":")[1].trim();
						if (host.contains(":")) {
							host = host.substring(0, host.indexOf(':'));
						}
					}
				}

				String path = firstLine[1];
				String paramString = "";

				if (path.contains("?")) {
					char[] charPath = path.toCharArray();
					int questionMarkIndex = 0;
					for (int i = 0; i < charPath.length; i++) {
						if (charPath[i] == '?') {
							questionMarkIndex = i;
							break;
						}
					}
					paramString = path.substring(questionMarkIndex + 1);
					path = path.substring(0, questionMarkIndex);
				}

				checkSession(request, path);

				if (!paramString.isEmpty()) {
					parseParameters(paramString);
				}

				internalDispatchRequest(path, true);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					csocket.close();
				} catch (IOException e) {
				}
			}
		}

		private void checkSession(List<String> request, String path) {

			String sidCandidate = "";
			for (String line : request) {
				if (!line.startsWith("Cookie:"))
					continue;

				String cookies = line.split(":")[1].trim();
				String[] cookieLine = cookies.split(";");

				for (String singleCookie : cookieLine) {
					String cookieKey = singleCookie.split("=")[0].trim();
					String cookieValue = singleCookie.split("=")[1].trim();

					if (cookieKey == null || cookieValue == null || cookieKey.isEmpty() || cookieValue.isEmpty())
						continue;
					if (cookieKey.equals(SID_STRING))
						sidCandidate = cookieValue.substring(1, cookieValue.length() - 1);
				}

			}
			synchronized (this) {
				if (sidCandidate.isEmpty() || !sessions.containsKey(sidCandidate)) {
					StringBuilder sb = new StringBuilder();
					for (int i = 0; i < SID_LENGTH; i++) {
						char c = (char) (sessionRandom.nextInt(26) + 65);
						sb.append(c);
					}

					sidCandidate = sb.toString();
					SID = sidCandidate;
					addSessionEntry(sidCandidate);
				} else {
					SessionMapEntry entry = sessions.get(sidCandidate);

					if ((System.currentTimeMillis() / 1000) >= entry.validUntil) {
						sessions.remove(entry.sid);
						StringBuilder sb = new StringBuilder();
						for (int i = 0; i < SID_LENGTH; i++) {
							char c = (char) (sessionRandom.nextInt(26) + 65);
							sb.append(c);
						}

						sidCandidate = sb.toString();
						SID = sidCandidate;
						addSessionEntry(sidCandidate);
					} else {
						SID = sidCandidate;
						entry.validUntil = (System.currentTimeMillis() / 1000) + sessionTimeout;
					}
				}
				permParams = sessions.get(SID).map;
			}
		}

		private synchronized void addSessionEntry(String sidCandidate) {

			long valid = System.currentTimeMillis() / 1000 + sessionTimeout;
			Map<String, String> map = new ConcurrentHashMap<>();
			map.put(SID_STRING, sidCandidate);

			outputCookies.forEach((cookie) -> map.put(cookie.name, cookie.value));

			sessions.put(sidCandidate, new SessionMapEntry(sidCandidate, host, valid, map));
			outputCookies.add(new RCCookie(SID_STRING, sidCandidate, null, host, "/"));
		}

		private void parseParameters(String paramString) {

			String[] parameters = paramString.split("&");

			for (String param : parameters) {
				String[] keyValue = param.split("=");
				params.put(keyValue[0], keyValue[1]);
			}

		}

		private List<String> readRequest() throws IOException {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int state = 0;
			l: while (true) {
				int b = istream.read();
				if (b == -1)
					return null;
				if (b != 13) {
					bos.write(b);
				}
				switch (state) {
				case 0:
					if (b == 13) {
						state = 1;
					} else if (b == 10)
						state = 4;
					break;
				case 1:
					if (b == 10) {
						state = 2;
					} else
						state = 0;
					break;
				case 2:
					if (b == 13) {
						state = 3;
					} else
						state = 0;
					break;
				case 3:
					if (b == 10) {
						break l;
					} else
						state = 0;
					break;
				case 4:
					if (b == 10) {
						break l;
					} else
						state = 0;
					break;
				}
			}
			byte[] request = bos.toByteArray();
			if (request == null) {
				sendError(400, "Bad request");
				return null;
			}
			String requestHeader = new String(request, StandardCharsets.US_ASCII);

			List<String> headers = new ArrayList<String>();
			String currentLine = null;
			for (String s : requestHeader.split("\n")) {
				if (s.isEmpty())
					break;
				char c = s.charAt(0);
				if (c == 9 || c == 32) {
					currentLine += s;
				} else {
					if (currentLine != null) {
						headers.add(currentLine);
					}
					currentLine = s;
				}
			}
			if (!currentLine.isEmpty()) {
				headers.add(currentLine);
			}
			return headers;
		}

		private void sendError(int statusCode, String statusText) throws IOException {

			ostream.write(("HTTP/1.1 " + statusCode + " " + statusText + "\r\n" + "Server: simple java server\r\n"
					+ "Content-Type: text/plain;charset=UTF-8\r\n" + "Content-Length: 0\r\n" + "Connection: close\r\n"
					+ "\r\n").getBytes(StandardCharsets.US_ASCII));
			ostream.flush();

		}

		@Override
		public void dispatchRequest(String urlPath) throws Exception {
			internalDispatchRequest(urlPath, false);
		}

		private void internalDispatchRequest(String urlPath, boolean directCall) throws IOException {

			if (context == null) {
				context = new RequestContext(ostream, params, permParams, outputCookies, tempParams, this);
			}

			if (urlPath.startsWith("/private/") || urlPath.equals("/private")) {
				if (directCall) {
					sendError(404, "Not found");
					return;
				}
			}

			if (urlPath.startsWith("/ext/")) {
				try {
					String fqcn = urlPath.substring(urlPath.lastIndexOf("/") + 1);
					Class<?> referenceToClass = Class.forName("hr.fer.zemris.java.webserver.workers." + fqcn);
					@SuppressWarnings("deprecation")
					Object newObject = referenceToClass.newInstance();
					IWebWorker iww = (IWebWorker) newObject;
					iww.processRequest(context);
				} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
					throw new RuntimeException("Error when trying to find the class given in workers properties.");
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}

			if (workersMap.containsKey(urlPath)) {
				try {
					workersMap.get(urlPath).processRequest(context);
					return;
				} catch (Exception e) {
				}
			}

			Path requestedPath = documentRoot.resolve(Paths.get(urlPath.substring(1))).toAbsolutePath();

			if (requestedPath.toString().endsWith(".smscr")) {
				try {
					byte[] buff = Files.readAllBytes(requestedPath);
					String fileContent = new String(buff, "UTF-8");

					if (context == null) {
						context = new RequestContext(ostream, params, permParams, outputCookies, tempParams, this);
					}

					new SmartScriptEngine(new SmartScriptParser(fileContent).getDocumentNode(), context).execute();

				} catch (NoSuchFileException e) {
					sendError(404, "Not found");
				}
				return;
			}

			if (!requestedPath.startsWith(documentRoot)) {
				sendError(403, "Forbidden");
				return;
			}

			if (!(Files.exists(requestedPath) && !Files.isDirectory(requestedPath)
					&& Files.isReadable(requestedPath))) {
				sendError(404, "Not found");
				return;
			}

			String extension = requestedPath.toString().substring(requestedPath.toString().lastIndexOf('.') + 1);

			String mime = mimeTypes.get(extension);
			if (mime == null) {
				mime = "application/octet-stream";
			}
			if (context == null)
				context = new RequestContext(ostream, params, permParams, outputCookies, tempParams, this);

			context.setMimeType(mime);
			context.setStatusCode(200);

			try (InputStream is = Files.newInputStream(requestedPath)) {

				byte[] buff = is.readAllBytes();
				context.write(buff);
			}
		}
	}
}
