package hr.fer.zemris.java.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class RequestContext {

	private static final int DEFAULT_STATUS_CODE = 200;

	private OutputStream outputStream;
	private Charset charset;

	public String encoding;
	public int statusCode;
	public String statusText;
	public String mimeType;

	private final Map<String, String> parameters;
	private Map<String, String> temporaryParameters;
	private Map<String, String> persistentParameters;
	private List<RCCookie> outputCookies;

	private boolean headerGenerated;

	private final IDispatcher dispatcher;

	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies) {
		
		this (outputStream, parameters, persistentParameters, outputCookies, new HashMap<>(), null);


		Objects.requireNonNull(outputStream, "Output stream can't be null");

//		this.outputStream = outputStream;
//		this.temporaryParameters = new HashMap<>();
//		this.parameters = parameters == null ? new HashMap<>() : parameters;
//		this.persistentParameters = persistentParameters == null ? new HashMap<>() : persistentParameters;
//		this.outputCookies = outputCookies == null ? new ArrayList<>() : outputCookies;
//		this.encoding = "UTF-8";
//		this.statusCode = DEFAULT_STATUS_CODE;
//		this.statusText = "OK";
//		this.mimeType = "text/html";
//		this.headerGenerated = false;
		

	}

	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies,
			Map<String, String> temporaryParameters, IDispatcher dispatcher) {

		Objects.requireNonNull(outputStream, "Output stream can't be null");

		this.outputStream = outputStream;
		this.temporaryParameters = temporaryParameters;
		this.parameters = parameters == null ? new HashMap<>() : parameters;
		this.persistentParameters = persistentParameters == null ? new HashMap<>() : persistentParameters;
		this.outputCookies = outputCookies == null ? new ArrayList<>() : outputCookies;
		this.encoding = "UTF-8";
		this.statusCode = DEFAULT_STATUS_CODE;
		this.statusText = "OK";
		this.mimeType = "text/html";
		this.headerGenerated = false;
		this.dispatcher = dispatcher;
	}

	public String getParameter(String name) {
		Objects.requireNonNull(name, "Parameters map key can't be null");
		return parameters.get(name);
	}

	public Set<String> getParameterNames() {
		return Collections.unmodifiableSet(parameters.keySet());
	}

	public String getPersistentParameter(String name) {
		Objects.requireNonNull(name, "Persistent parameter map key can't be null");
		return persistentParameters.get(name);
	}

	public Set<String> getPersistentParameterNames() {
		return Collections.unmodifiableSet(persistentParameters.keySet());
	}

	public void setPersistentParameter(String name, String value) {
		Objects.requireNonNull(name, "Persistent Parameters map key can't be null");
		Objects.requireNonNull(value, "Persistent Parameters map key can't be null");

		persistentParameters.put(name, value);
	}

	public void removePersistentParameter(String name) {
		Objects.requireNonNull(name, "Persistent Parameters map key can't be null");

		persistentParameters.remove(name);
	}

	public String getTemporaryParameter(String name) {
		Objects.requireNonNull(name, "Temporary Parameters map key can't be null");

		return temporaryParameters.get(name);
	}

	public Set<String> getTemporaryParameterNames() {
		return Collections.unmodifiableSet(temporaryParameters.keySet());
	}

	public void setTemporaryParameter(String name, String value) {
		Objects.requireNonNull(name, "Temporary Parameters map key can't be null");
		Objects.requireNonNull(value, "Temporary Parameters map key can't be null");

		temporaryParameters.put(name, value);
	}

	public void removeTemporaryParameter(String name) {
		Objects.requireNonNull(name, "Temporary Parameters map key can't be null");

		temporaryParameters.remove(name);
	}

	public RequestContext write(byte[] data) throws IOException {
		if (!headerGenerated) {
			generateHeader();
		}

		outputStream.write(data);
		return this;
	}

	public RequestContext write(String text) throws IOException {
		if (!headerGenerated) {
			generateHeader();
		}

		byte[] buff = text.getBytes(charset);
		outputStream.write(buff);
		return this;
	}

	private void generateHeader() {

		charset = Charset.forName(encoding);

		String header = "HTTP/1.1 " + statusCode + " " + statusText + "\r\n" + "Content-Type: " + getContentType()
				+ "\r\n" + appendCookies() + "\r\n";

		try {
			outputStream.write(header.getBytes(Charset.forName("ISO_8859_1")));
		} catch (IOException e) {
			e.printStackTrace();
		}

		headerGenerated = true;
	}

	private String appendCookies() {

		if (outputCookies.isEmpty())
			return "";

		StringBuilder cookieBlock = new StringBuilder();

		for (RCCookie cookie : outputCookies) {

			StringBuilder cookieLineBuilder = new StringBuilder();

			cookieLineBuilder.append("Set-Cookie: ");
			cookieLineBuilder.append(cookie.name + "=\"" + cookie.value + "\"; ");
			cookieLineBuilder.append(cookie.domain == null ? "" : "Domain=" + cookie.domain + "; ");
			cookieLineBuilder.append(cookie.path == null ? "" : "Path=" + cookie.path + "; ");
			cookieLineBuilder.append(cookie.maxAge == null ? "" : "Max-Age=" + cookie.maxAge + "; ");

			String line = cookieLineBuilder.toString().trim();

			if (line.endsWith(";")) {
				line = line.substring(0, line.length() - 1);
			}

			cookieBlock.append(line).append("\r\n");
		}
		return cookieBlock.toString();
	}

	private String getContentType() {
		String contentType = mimeType;
		if (mimeType.startsWith("text/")) {
			contentType += "; charset=" + encoding;
		}
		return contentType;
	}

	public void setEncoding(String encoding) {
		if (headerGenerated) throw new RuntimeException("Encoding can't be modified after header's been created.");
		
		this.encoding = encoding;
	}

	public void setStatusCode(int statusCode) {
		if (headerGenerated) throw new RuntimeException("Status code can't be modified after header's been created.");
		
		this.statusCode = statusCode;
	}

	public void setStatusText(String statusText) {
		if (headerGenerated) throw new RuntimeException("Status text can't be modified after header's been created.");

		this.statusText = statusText;
	}

	public void setMimeType(String mimeType) {
		if (headerGenerated) throw new RuntimeException("Mime type can't be modified after header's been created.");

		this.mimeType = mimeType;
	}

	public IDispatcher getDispatcher() {
		return dispatcher;
	}
	

	public static class RCCookie {

		final String name;
		final String value;
		final String domain;
		final String path;
		final Integer maxAge;

		public RCCookie(String name, String value, Integer maxAge, String domain, String path) {
			this.name = name;
			this.value = value;
			this.maxAge = maxAge;
			this.domain = domain;
			this.path = path;
		}

	}

	public void addRCCookie(RCCookie rcCookie) {
		Objects.requireNonNull(rcCookie, "Given cookie can't be null.");
		if (headerGenerated) throw new RuntimeException("Encoding can't be modified after header's been created.");

		outputCookies.add(rcCookie);
	}
}
