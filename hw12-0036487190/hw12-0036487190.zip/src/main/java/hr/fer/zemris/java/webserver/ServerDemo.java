package hr.fer.zemris.java.webserver;

public class ServerDemo {
	
	public static void main(String[] args) {
		SmartHttpServer server = new SmartHttpServer("server.properties");
		server.start();

	}
	
}
